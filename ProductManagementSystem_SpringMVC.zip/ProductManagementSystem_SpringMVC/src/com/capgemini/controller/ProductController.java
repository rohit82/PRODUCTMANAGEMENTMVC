package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.jsp.jstl.sql.Result;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;

@Controller
public class ProductController {

	@Autowired
	IProductService productService;

	public ProductController() {
		// TODO Auto-generated constructor stub
	}

	public ProductController(IProductService productService) {
		super();
		this.productService = productService;
	}

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}

	// provides the home page to client
	@RequestMapping("home")
	public String getHomePage() {
		return "HomePage";
	}

	// initializing Add Product jsp
	@RequestMapping("addproduct")
	public String getAddProductPage(Model model) {

		// init the data for category drop down list
		List<String> categories = new ArrayList<>();
		categories.add("shoes");
		categories.add("Electronics");
		categories.add("clothes");
		categories.add("books");
		categories.add("hometools");
		categories.add("furniture");

		// add the form backinngbean to be binded to addProduct.jsp form
		model.addAttribute("product", new Product());

		model.addAttribute("categories", categories);
		return "AddProductPage";
	}

	@RequestMapping(value = "ProcessAddProductForm")
	public ModelAndView processAddProductForm(
			@ModelAttribute("product") @Valid Product product,
			BindingResult result, Model model) {
		if (result.hasErrors() == true) {

			// init the data for category drop down list
			List<String> categories = new ArrayList<>();
			categories.add("shoes");
			categories.add("Electronics");
			categories.add("clothes");
			categories.add("books");
			categories.add("hometools");
			categories.add("furniture");

			// add the form backinngbean to be binded to addProduct.jsp form
			model.addAttribute("product", product);

			model.addAttribute("categories", categories);
			return new ModelAndView("AddProductPage");
		}
		try {
			int productId = productService.addProduct(product);
			model.addAttribute("message",
					"Product Added Successfully. Product id:" + productId);
			return new ModelAndView("SuccessPage");

		} catch (Exception e) {
			model.addAttribute("errMsg",
					"Could not add product. Reason" + e.getMessage());

			return new ModelAndView("ErroPage");
		}
	}

	@RequestMapping("getproduct")
	public String getProductPage() {
		return "GetProductPage";
	}

	@RequestMapping("processgetproductform")
	public ModelAndView processGetProductForm(@RequestParam("productId") int pid) {
		Product product = null;
		try {
			product = productService.getProduct(pid);
			return new ModelAndView("GetProductPage", "product", product);
		} catch (Exception e) {
			return new ModelAndView("ErrorPage", "errMsg",
					"Could not retrieve the product.Reason:" + e.getMessage());

		}

	}

	@RequestMapping("viewallproducts")
	public String getViewAllProductsPage(Model model) {
		List<Product> products = null;
		try {
			products = productService.getAllProducts();

			model.addAttribute("products", products);
		} catch (Exception e) {

			model.addAttribute("errMsg", "Could not display Products. Reason:"
					+ e.getMessage());

			return "ErrorPage";
		}
		return "ViewAllProductsPage";
	}

	@RequestMapping("getupdatepage")
	public String getUpdatePage(@RequestParam("pid") int id, Model model) {
		// init the data for category drop down list
		List<String> categories = new ArrayList<>();
		categories.add("shoes");
		categories.add("Electronics");
		categories.add("clothes");
		categories.add("books");
		categories.add("hometools");
		categories.add("furniture");

		Product product = null;
		try {
			product = productService.getProduct(id);

		} catch (Exception e) {
			model.addAttribute(
					"errMsg",
					"Could not retrieve Product Details. Reason :"
							+ e.getMessage());
			return "ErrorPage";
		}
		// add the form backinngbean to be binded to addProduct.jsp form
		model.addAttribute("product", product);

		model.addAttribute("categories", categories);

		return "UpdatePage";

	}

	@RequestMapping(value = "processupdatepageform", method = RequestMethod.POST)
	public String processUpdatePageForm(
			@ModelAttribute("product") @Valid Product product,
			BindingResult res, Model model) {
		if ( res.hasErrors() == true)
			
		
		{

			// init the data for category drop down list
			List<String> categories = new ArrayList<>();
			categories.add("shoes");
			categories.add("Electronics");
			categories.add("clothes");
			categories.add("books");
			categories.add("hometools");
			categories.add("furniture");

			// add the form backinngbean to be binded to addProduct.jsp form
			model.addAttribute("product", product);

			model.addAttribute("categories", categories);
			return "UpdatePage";
		}

		try
		{
			productService.updateProduct(product);
		}
		catch (Exception e) 
		{
		model.addAttribute("errMsg", "Could not update product details. Reason :" + e.getMessage());
		return "ErrorPage";
		}
		model.addAttribute("message", "Product Update Successfully");
		return "SuccessPage";
	}

}
