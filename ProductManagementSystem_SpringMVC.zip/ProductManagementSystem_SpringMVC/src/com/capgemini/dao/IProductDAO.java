package com.capgemini.dao;

import java.util.List;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

public interface IProductDAO 
{
	public int addProduct(Product product) throws ProductException;
	public void updateProduct(Product product) throws ProductException;
	public Product getProduct(int id) throws ProductException;
	public void removeProduct(int id) throws ProductException;
	public List<Product> getAllProducts() throws ProductException ;
	public Product getProductByName(String name) throws ProductException ;
	public List<Product> getProductByPrice( float min , float max ) throws ProductException ;
}
