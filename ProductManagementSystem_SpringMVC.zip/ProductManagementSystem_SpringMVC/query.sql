create sequence productid_seq start with 1000 increment by 1;

select * from ProductDetails;